import keras
from keras import backend as K
from keras.layers import Layer
import tensorflow as tf
from keras import activations, initializers, constraints
import numpy as np

class HoGCN(Layer):

	def __init__(self, output_dim=None, kernel_initializer='glorot_uniform', kernel_regularizer=None, kernel_constraint=None, weight_initializer='glorot_uniform', weight_regularizer=None, weight_constraint=None,use_bias=True, bias_initializer='zeros', bias_regularizer=None, bias_constraint=None,**kwargs):
		self.output_dim = output_dim
		self.kernel_initializer = keras.initializers.get(kernel_initializer)
		self.kernel_regularizer = keras.regularizers.get(kernel_regularizer)
		self.kernel_constraint = keras.constraints.get(kernel_constraint)
		self.use_bias = use_bias
		self.bias_initializer = keras.initializers.get(bias_initializer)
		self.bias_regularizer = keras.regularizers.get(bias_regularizer)
		self.bias_constraint = keras.constraints.get(bias_constraint)
		self.weight_initializer = keras.initializers.get(weight_initializer)
		self.weight_regularizer = keras.regularizers.get(weight_regularizer)
		self.weight_constraint = keras.constraints.get(weight_constraint)
		self.kernelQ, self.kernelK, self.kernelV,self.W1,self.W2,self.W3,self.sparsity_gate ,self.b = None, None, None, None,None,None,None,None
		super(HoGCN, self).__init__(**kwargs)

	def build(self, input_shape):
		assert isinstance(input_shape, list)
		bt, T, n, f=input_shape[-1]
		a=input_shape[-1]
		k=np.array(a)
		b =k[2]
		# Create a trainable weight variable for this layer.
		self.kernelQ = self.add_weight(name='kernelQ', shape=(f, self.output_dim), initializer='uniform', trainable=True, regularizer=self.kernel_regularizer, constraint=self.kernel_constraint)
		self.kernelK = self.add_weight(name='kernelK', shape=(f, self.output_dim), initializer='uniform', trainable=True, regularizer=self.kernel_regularizer, constraint=self.kernel_constraint)
		self.kernelV = self.add_weight(name='kernelV', shape=(f, self.output_dim), initializer='uniform', trainable=True, regularizer=self.kernel_regularizer, constraint=self.kernel_constraint)
		self.W1 = self.add_weight(name='W1',shape=(self.output_dim,b), initializer=self.weight_initializer, trainable=True, regularizer=self.weight_regularizer, constraint=self.weight_constraint)
		self.W2 = self.add_weight(name='W2',shape=(self.output_dim,b), initializer=self.weight_initializer,  trainable=True, regularizer=self.weight_regularizer, constraint=self.weight_constraint)
		self.W3 = self.add_weight(name='W3',shape=(b, b), initializer=self.weight_initializer,  trainable=True, regularizer=self.weight_regularizer, constraint=self.weight_constraint)

		# Trainable gate for controlling sparsity
		self.sparsity_gate = self.add_weight(name='sparsity_gate', shape=(1,), initializer='ones', trainable=True)
			
		if self.use_bias:
			#self.b = self.add_weight(shape=(n, self.output_dim), initializer=self.bias_initializer, regularizer=self.bias_regularizer, constraint=self.bias_constraint, name='{}_b'.format(self.name),)
			self.b = self.add_weight(shape=(n, (self.output_dim)*3), initializer=self.bias_initializer, regularizer=self.bias_regularizer, constraint=self.bias_constraint, name='{}_b'.format(self.name),)
			
			
			
		super(HoGCN, self).build(input_shape)  # Be sure to call this at the end

	def call(self,lisX):
		assert isinstance(lisX, list)
		a, x=lisX
		bt,t, n, f=x.get_shape().as_list()
		
		def mha(x):
			xQ=tf.matmul(x, self.kernelQ)
			print("kernel Q",self.kernelQ.shape)
			print("x",x.shape)
			print("xQ",xQ.shape)
			xK=tf.matmul(x, self.kernelK)
			print("xk",xK.shape)
			xV=tf.matmul(x, self.kernelV)
			#out=(tf.matmul(xQ,self.W1)
			#out=tf.matmul(tf.nn.softmax(tf.matmul(xQ, xK, transpose_b=True), axis=-1), xV)
			#xK=tf.transpose(xK, [0,1,3,2])

			#s3
			out1=tf.matmul(xK,self.W1)
			print("out1",out1.shape)
			A=tf.nn.softmax(tf.matmul(out1,xQ))
			print("A",A.shape)

			threshold = self.sparsity_gate * tf.reduce_mean(A)  # Dynamic threshold based on gate

			#threshold = tf.reduce_mean(A)  # You can adjust this value based on your needs
			A_sparse = tf.where(A < threshold, tf.zeros_like(A), A)
			print("A (after sparsity)", A_sparse.shape)
			
			A_sparse=tf.matmul(A_sparse, self.W2)
			#print("A_final",A.shape)
			out1=tf.matmul(A_sparse,xV)
			print("out1",out1.shape)
			
			#out=tf.matmul(tf.nn.tanh(tf.matmul(xQ, out1)), xV)
			#out=tf.matmul(tf.nn.softmax(p), xV)


			#s2
			m=tf.matmul(xK,self.W2)
			print("m",m.shape)
			o=tf.matmul(xQ,self.W1)
			p=tf.keras.layers.Add()([m, o])
			print("p",p.shape)
			#print("B",B.shape)
			#out2=tf.matmul(tf.nn.tanh(p), xV)
			out2=tf.matmul(tf.nn.softmax(tf.matmul(tf.nn.tanh(p),self.W3, transpose_b=True),axis=-1),A_sparse)
			sparse=tf.matmul(out2,xV)

			#s1
			out3=tf.matmul(tf.nn.softmax(tf.matmul(xQ, xK, transpose_b=True), axis=-1), xV)
			#sparse multiplicative attention
			#outs=tf.nn.sigmoid(tf.matmul(xQ, out1, transpose_b=True))
			#sparse=tf.matmul(outs,out1)
			out=tf.keras.layers.Concatenate(axis=-1)([out1,sparse,out3])
			#out=tf.matmul(tf.nn.softmax(p), xV)
			print("out",out.shape)
			
			return out
			
			
		out=mha(x)
		if self.use_bias:
			out+= self.b
		out=tf.nn.leaky_relu(out, alpha=0.1)
		return out

	def get_config(self):
		config = super(HoGCN, self).get_config()
		config.update({"output_dim": self.output_dim})
		return config

	def compute_output_shape(self,input_shape):
		assert isinstance(input_shape, list)
		bt, T, n, f=input_shape[1]
		return (bt, T, n, self.output_dim)
		
