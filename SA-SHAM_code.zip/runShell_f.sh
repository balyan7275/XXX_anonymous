
python -W ignore getData_f.py THS 24 12 15
python -W ignore getData_f.py THS 24 12 20
python -W ignore getData_f.py THS 24 12 25
python -W ignore getData_f.py THS 24 12 30
python -W ignore getData_f.py THS 24 12 35
python -W ignore getData_f.py THS 24 12 40
python -W ignore getData_f.py THS 24 12 50
python -W ignore getData_f.py THS 24 12 65
python -W ignore getData_f.py THS 24 12 80
python -W ignore getData_f.py THS 24 12 100

python -W ignore getData_f.py THS 24 10 15
python -W ignore getData_f.py THS 24 10 25
python -W ignore getData_f.py THS 24 10 80
python -W ignore getData_f.py THS 24 10 110
python -W ignore getData_f.py THS 24 10 130
python -W ignore getData_f.py THS 24 10 160
python -W ignore getData_f.py THS 24 10 170


python -W ignore getData_f.py THS 24 8 15
python -W ignore getData_f.py THS 24 8 20
python -W ignore getData_f.py THS 24 8 40
python -W ignore getData_f.py THS 24 8 50
python -W ignore getData_f.py THS 24 8 90
python -W ignore getData_f.py THS 24 8 170
python -W ignore getData_f.py THS 24 8 200
python -W ignore getData_f.py THS 24 8 205


python -W ignore getData_f.py THS 24 6 25
python -W ignore getData_f.py THS 24 6 30
python -W ignore getData_f.py THS 24 6 40
python -W ignore getData_f.py THS 24 6 48
python -W ignore getData_f.py THS 24 6 75
python -W ignore getData_f.py THS 24 6 120
python -W ignore getData_f.py THS 24 6 140
python -W ignore getData_f.py THS 24 6 175
python -W ignore getData_f.py THS 24 6 180


python -W ignore getData_f.py THS 24 4 20
python -W ignore getData_f.py THS 24 4 25
python -W ignore getData_f.py THS 24 4 32
python -W ignore getData_f.py THS 24 4 38
python -W ignore getData_f.py THS 24 4 52
python -W ignore getData_f.py THS 24 4 78
python -W ignore getData_f.py THS 24 4 98
python -W ignore getData_f.py THS 24 4 150

python -W ignore getData_f.py THS 24 2 20
python -W ignore getData_f.py THS 24 2 30
python -W ignore getData_f.py THS 24 2 40
python -W ignore getData_f.py THS 24 2 54
python -W ignore getData_f.py THS 24 2 120
python -W ignore getData_f.py THS 24 2 170


python -W ignore getData_f.py THS 24 1 15
python -W ignore getData_f.py THS 24 1 25
python -W ignore getData_f.py THS 24 1 40
python -W ignore getData_f.py THS 24 1 48
python -W ignore getData_f.py THS 24 1 58
python -W ignore getData_f.py THS 24 1 140
python -W ignore getData_f.py THS 24 1 160