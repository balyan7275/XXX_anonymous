#import os
#os.environ["CUDA_DEVICE_ORDER"] = "PCI_BUS_ID" 
#os.environ["CUDA_VISIBLE_DEVICES"] = "2"

import os
os.environ['PYTHONHASHSEED'] = '0'
os.environ['KERAS_BACKEND'] = 'tensorflow'
#os.environ['CUDA_VISIBLE_DEVICES'] = '-1'
import random
random.seed(0)
import numpy as np
np.random.seed(0)
import tensorflow as tf
#from tensorflow import set_random_seed
#set_random_seed(1)
tf.random.set_seed(2)

import sys
import pandas as pd
#import numpy as np
#np.random.seed(0)
import keras
from keras.layers import Layer
import keras.backend as K
#import tensorflow as tf
#from keras.utils import plot_model
from keras.utils.vis_utils import plot_model
from keras.models import Model
from keras import Input#, Model
from tensorflow.keras.optimizers import Adam
#from keras.optimizers import Adam
from keras.regularizers import l2
from keras.layers import Flatten, Dense, Lambda, Dot, LSTM, Reshape, TimeDistributed, Dropout, BatchNormalization, Concatenate, Reshape
from keras.models import load_model

from keras.layers import Bidirectional

from HOGCN_f import HoGCN
from HOGCNT_f import HoGCNT
#from DECODER import Decoder
from DECODER_1 import Decoder

import numpy as np
from numpy import *
from scipy.stats import pearsonr
import tensorflow as tf

opt = Adam(lr=0.00999)
keras.regularizers.l1(0.01)
keras.regularizers.l2(0.01)
keras.regularizers.l1_l2(l1=0.01, l2=0.01)

def l1_reg(weight_matrix):
    return 0.00001 * K.sum(K.abs(weight_matrix))

class Froc:
	
	def __init__(self):
		print ("Encoder Class is instantiated.")

	def _proc(self):
		print ("proctected scope")

	def demo(self):
		print ("public scope method")
		
	def var(self, x):
		sp=x.get_shape().as_list()
		m=tf.reduce_mean(x, axis=2, keepdims=True)
		x=x-m
		x=tf.multiply(x, x)
		x=x/(sp[1]-tf.constant([1], dtype=x.dtype))
		x=tf.reduce_sum(x, axis=2, keepdims=True)
		x=tf.sigmoid(x)
		x=tf.subtract(tf.constant(1, dtype=x.dtype), x)
		x=tf.reshape(x, [-1, sp[1]*sp[3]])
		#print (x.shape, m.shape)
		#input("inside variance")
		return x		
		
	def froc(self, **kwargs):
		#all inputs
		batch=kwargs["batch"]
		A=kwargs["A"]
		X=kwargs["X"]
		Hwnd=kwargs["Hwnd"]
		ds_dim=kwargs["ds_dim"]
		dt_dim=kwargs["dt_dim"]
		pWnd=kwargs["pWnd"]
		
		#print(A)
		#print(np.shape(A))
		
		#correlation
		
		
		Y=np.load("activeODTTHS3m_30.npy")
		Y=np.array(Y)
		#X[25][2160]
		arr3= list(range(2160))
		arr3=np.array(arr3)
		arr3=arr3.astype(np.float)
		my_dict = list(range(625))
		val=0
		for i in range(0,25):
		
		        for j in range(0,25):
		                for k in range(0,2160):
		                
		                        #print(Y[k][i][j]/2160)
		                        arr3[k]=(Y[k][i][j])
		                my_dict[i*25+j]=arr3
		                arr3 = [0]*2160
		
		rows,cols=(25,25)
		adj_corr = [[0]*cols]*rows
		adj_corr=np.array(adj_corr)
		adj_corr=adj_corr.astype(np.float)
		
		for i in range(0,25):


		        for j in range(0,25):
		                corr, _ = pearsonr(my_dict[i],my_dict[j+25*i])
		                if isnan(corr):
		                
		                        adj_corr[i][j]=1
		                else:
		                        adj_corr[i][j]=corr
                #model
		vis_A=Input(shape=(24, )+A)
		vis_X=Input(shape=(24, )+X)

		vis_A1=Input(shape=(4, )+A)
		vis_X1=Input(shape=(4, )+X)
		
		vis_A2=Input(shape=(28, )+A)
		vis_X2=Input(shape=(28, )+X)
		
		H=HoGCN(ds_dim,kernel_regularizer=l1_reg,weight_regularizer=l1_reg, bias_regularizer=l1_reg, use_bias=True)([vis_A, vis_X])
		#H2=HoGCN(6,kernel_regularizer=l1_reg,weight_regularizer=l1_reg, bias_regularizer=l1_reg, use_bias=True)([vis_A, vis_X])
		#H=tf.keras.layers.Concatenate(axis=-1, name="concatenation_spatial_features")([H1, H2])
		print("final_spatial embedding",H.shape)
		print("visA shape",vis_A.shape)
		print("visX shape",vis_X.shape)

		#B=tf.matmul(vis_A2,vis_X2)
		#print("B shape",B.shape)
		#ax0, ax1, ax2, ax3=B.get_shape().as_list()
		#B=Reshape((ax2, ax1, ax3))(B)
		#print("B_spatial embedding",B.shape)
		
		B=tf.matmul(vis_A,vis_X)
		print("B1 shape",B.shape)
		ax0, ax1, ax2, ax3=B.get_shape().as_list()
		B=Reshape((ax2, ax1, ax3))(B)
		print("B_spatial embedding",B.shape)

		#B2=tf.matmul(vis_A1,vis_X1)
		#print("B2shape",B2.shape)
		#ax0, ax1, ax2, ax3=B2.get_shape().as_list()
		#B2=Reshape((ax2, ax1, ax3))(B2)
		#print("B2_spatial embedding",B2.shape)
		#tf.keras.layers.Reshape((None, 25, 24, 2), B)
		#B =tf.make_ndarray(B)
		#B=B.reshape((0,2,1,3))
		#B=tf.convert_to_tensor(B)
		#B=Reshape((ax0,ax2, ax1, ax3))(B)
		#H=HoGCN(ds_dim,kernel_regularizer=l1_reg, bias_regularizer=l1_reg, use_bias=True)([vis_A, vis_X])
		#print("H_spatial embedding",H.shape)
		#ax0, ax1, ax2, ax3=H.get_shape().as_list()
		#H=Lambda(lambda x:tf.reshape(x, [-1, ax2, ax1, ax3]))(H)##-1 would help but not ax0 as it might be None
		#H=Reshape((ax2, ax1, ax3))(H)
		T=HoGCNT(dt_dim, kernel_regularizer=l1_reg,weight_regularizer=l1_reg, bias_regularizer=l1_reg, use_bias=True)(B)
		#T2=HoGCNT(4, kernel_regularizer=l1_reg,weight_regularizer=l1_reg, bias_regularizer=l1_reg, use_bias=True)(B1)
		#T=tf.keras.layers.Concatenate(axis=-1, name="concatenation_temporal_features")([T1, T2])
		print("T_temporal embedding",T.shape)
		#print("T1_temporal embedding",T1.shape)
		#print("T2_temporal embedding",T2.shape)
		#H=HoGCNT(dt_dim, kernel_regularizer=l1_reg, bias_regularizer=l1_reg, use_bias=True)(H)
		ax0, ax1, ax2, ax3=T.get_shape().as_list()
		T=Reshape((ax2, ax1, ax3))(T)
		#tf.keras.T.Permute(0,2,1,3)
		#print("T1_shape given to decoder",T1.shape)
		#ax0, ax1, ax2, ax3=T2.get_shape().as_list()
		#T2=Reshape((ax2, ax1, ax3))(T2)
		#print("T2_shape given to decoder",T1.shape)
		#H=Lambda(lambda x:tf.reshape(x, [-1, ax2, ax1, ax3]))(H)
		#H=Dense(50, activation="sigmoid")(H)
		#H=tf.keras.layers.Add()([H, T])

		#T=tf.keras.layers.Concatenate(axis=-1, name="concatenation_features")([T1, T2])
		#print("temporal final_shape given to decoder",T.shape)
		#ax0, ax1, ax2, ax3=T.get_shape().as_list()
		#T=Reshape((ax2, ax1, ax3))(T)
		#print("T_shape given to decoder",T.shape)
		#H=tf.keras.layers.Concatenate(axis=-1, name="concatenation_ST_features")([H, T])
		
		H=tf.keras.layers.Concatenate(axis=-1, name="concatenation_features1")([H, T])
		#H2=tf.keras.layers.Concatenate(axis=-1, name="concatenation_features2")([H2, T2])
		print("H shape given to decoder",H.shape)
		#print("H_1shape given to decoder",H1.shape)
		#print("H_2shape given to decoder",H2.shape)
		D=Decoder(pwnd=pWnd)(H)
		#D2=Decoder(pwnd=pWnd)(H2)
		#D = Decoder(pwnd=pWnd)(H)
		#D1 = Decoder(pwnd=pWnd, name='decoder_1')(H1)
		#D2 = Decoder(pwnd=pWnd, name='decoder_2')(H2)
		
		#print("D_1shape given to decoder",D1.shape)
		#print("D_2shape given to decoder",D2.shape)
		#D= Concatenate(axis=-1)([D1, D2])
		#D=tf.keras.layers.Concatenate(axis=-1, name="concatenation_features")([D1, D2])
		
		
		#print("D shape given to decoder",D.shape)
		model = Model([vis_A, vis_X], D)
		
		
		lossL=["mean_squared_error"]
		
		model.compile(optimizer=opt, loss=lossL, metrics=['accuracy'])
		# summarize layers
		print(model.summary())
		# plot graph
		#plot_model(model, to_file='repo/enDe.png')

		return model	

	def saveModel(self, model, saveModel):
		model.save(saveModel)
		return model

	def loadModel(self, saveModel):
		model=load_model(saveModel, custom_objects={"tf":tf, "HoGCN":HoGCN, "HoGCNT":HoGCNT, "Decoder":Decoder})
		return model	
		
def prog():
	#temporal sequence
	samples=256; batch=32
	#nodes, features dim
	n=25; f=2; ds_dim=12; dt_dim=8; k_depth=4; pWnd=5; Hwnd=24
	kwargs={"batch":batch, "Hwnd":24, "A":(n, n), "X":(n, f), "ds_dim":ds_dim, "dt_dim":dt_dim, "pWnd":pWnd}
	frc=Froc()
	model=frc.froc(**kwargs)
	
	X=[np.random.uniform(low=0, high=100, size=(320, Hwnd, n, n))]
	
	return

#prog()
