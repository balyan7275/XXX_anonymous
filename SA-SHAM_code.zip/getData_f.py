import os
os.environ['PYTHONHASHSEED'] = '0'
os.environ['KERAS_BACKEND'] = 'tensorflow'
os.environ['CUDA_VISIBLE_DEVICES'] = '-1'
os.environ['KMP_WARNINGS'] = '0'
import random
random.seed(0)
import numpy as np
np.random.seed(0)
import tensorflow as tf
#from tensorflow import set_random_seed
#set_random_seed(1)
tf.random.set_seed(2)
from tensorflow.keras import backend as K
import pandas as pd
import copy
#from HOGCN import STransformer
from keras.models import load_model
from keras.models import Model
import pickle
import sys
import math


from FROC_Cheby_1 import Froc

#################################################
ntw=sys.argv[1]#"NYC"#"NYC"#"THS" ****************************************
ntwD={"NYC":55, "THS":25}
#Pwnd=int(sys.argv[1])

hWnd=int(sys.argv[2])#24 *************************************************
pWnd=int(sys.argv[3])#12 *************************************************
per=0.835
f=2
ds_dim=12
dt_dim=8
k_depth=4
node=ntwD[ntw]
batch_size=16
Epochs=int(sys.argv[4])#470 ************************************************

ODT="../../Data/"+ntw+"/"+"activeODT"+ntw+"3m_30.npy"
geoAdj="../../Data/"+ntw+"/geo30"+ntw+"3m.npy"



print(ODT)
print(type(geoAdj))

mnF="res/"+ntw+"/mn.npy"
mxF="res/"+ntw+"/mx.npy"
dfStatsFile="res/"+ntw+"/dfStats_"+str(hWnd)+"_"+str(pWnd)+"_"+str(Epochs)+".csv"
saveModel="res/"+ntw+"/FROC.h5"

predArr="res/"+ntw+"/pred_"+str(hWnd)+"_"+str(pWnd)+".npy"
realArr="res/"+ntw+"/real_"+str(hWnd)+"_"+str(pWnd)+".npy"

dfResFile="res/"+ntw+"/dfRes.csv"
dfRes=pd.DataFrame(columns=["HWND", "PWND", "Epochs", "RMSE", "MAPE", "SMAPE"])
if os.path.exists(dfResFile):
	dfRes=pd.read_csv(dfResFile)

#################################################changes above

#rounding odt
def rnd(x):
	if isinstance(x, list):
		N=len(x)
	else:
		N=x.shape[0]
	for i in range(N):
		a=x[i]
		a[~np.isfinite(a)]=0
		a[a<=0]=0
		a=np.around(a)
		x[i]=a
	x=x.astype(int)
	return x

#desensitize odt with weekly historic values on hours
def minMax(odt, ts, mnF, mxF):
	t, n, m=odt.shape[0], odt.shape[1], odt.shape[2]
	mn=odt[:ts].min(axis=0); mx=odt[:ts].max(axis=0); dmx=copy.deepcopy(mx); dmx[dmx==0]=1
	odt=(odt-mn)/(dmx-mn)
	np.save(mnF, mn)
	np.save(mxF, mx)
	return odt, mn, mx##rescaling is just simple as res*(mx-mn)+mn

def getXY():
	
	odt=np.load(ODT)#(T, n, n)
	odt[~np.isfinite(odt)]=0
	
	T, n, n=odt.shape
	samples=T-(hWnd+pWnd)+1	
	
	odt, mn, mx=minMax(odt, int(0.835*samples), mnF, mxF)
	#get train-test X Y
	x=np.zeros((samples, hWnd, n, n))
	fs=np.zeros((samples, hWnd, n, f))
	y=np.zeros((samples, pWnd, n, n))

	for i in range(samples):
		x[i, ::]=odt[i:i+hWnd, ::]
		fs[i, ::]=np.stack((odt[i:i+hWnd, ::].sum(axis=1), odt[i:i+hWnd, ::].sum(axis=2)), axis=2)
		y[i, ::]=odt[i+hWnd:i+hWnd+pWnd, ::]		

	trN=int(0.835*samples); trN=trN-trN%batch_size; tsN=samples-trN
	
	xTs=x[-tsN:]; fsTs=fs[-tsN:]; yTs=y[-tsN:] 
	
	tsN=tsN-tsN%batch_size
	
	xTs=xTs[:tsN]; fsTs=fsTs[:tsN] ; yTs=yTs[:tsN]
	
	vN=int(0.13*trN/batch_size)*batch_size##validation
	
	xV=x[:trN][-vN:]; fsV=fs[:trN][-vN:]; yV=y[:trN][-vN:]
	
	trN=trN-vN
	xTr=x[:trN]; fsTr=fs[:trN] ; yTr=y[:trN]	
	
	oTr=np.zeros((xTr.shape[0], 1)); oV=np.zeros((xV.shape[0], 1)); oTs=np.zeros((xTs.shape[0], 1))
	
	ovn=6
	
	XL=[xTr, fsTr]; YL=yTr
	XVL=[xV, fsV]; YVL=yV
	XTL=[xTs, fsTs]; YTL=yTs
	
	#print ("\n training ", [x.shape for x in XL], yTr.shape)
	#print ("\n validation ", [x.shape for x in XVL], yV.shape)
	#print ("\n testing ", [x.shape for x in XTL], yTs.shape)#; input("enter")

	return XL, XVL, XTL, yTr, yV, yTs, mn, mx


#getFiles_n_Model()

######################################### training and testing 


def execute():

	XL, XVL, XTL, yTr, yV, yTs, mn, mx=getXY()	
	
	kwargs={"batch":batch_size, "Hwnd":hWnd, "A":(node, node), "X":(node, f), "ds_dim":ds_dim, "dt_dim":dt_dim, "k_depth":k_depth, "pWnd":pWnd}
		
	frc=Froc()
	model=frc.froc(**kwargs)
	dfStats=pd.DataFrame()#(columns=["loss", "accuracy", "val_loss", "val_accuracy"])
	his=model.fit(XL, yTr, epochs=Epochs, batch_size=batch_size, validation_data=(XVL, yV), verbose=2)
	#print (his.history)
	dfStats["loss"]=his.history["loss"]
	dfStats["accuracy"]=his.history["accuracy"]
	dfStats["val_loss"]=his.history["val_loss"]
	dfStats["val_accuracy"]=his.history["val_accuracy"]
	dfStats.to_csv(dfStatsFile, index=False)

	#save and load model
	frc.saveModel(model, saveModel)
	###model=frc.loadModel(saveModel)
	
	
	#prediction testing
	pred=model.predict(XTL)#; input ("enter") # (sample, t, n, n)
	print ("sum before ", pred.sum(), yTs.sum(), pred.shape, yTs.shape, mn.shape, mx.shape, mn.sum(), mx.sum())	
	pred=pred*(mx-mn)+mn; pred=rnd(pred)
	yTs=yTs*(mx-mn)+mn; yTs=rnd(yTs)
	print ("sum after ", pred.sum(), yTs.sum())
	rmse=np.sqrt(np.mean(np.square(yTs-pred)))
	print ("rmse ", rmse, pred.sum(), yTs.sum())

	np.save(predArr, pred); np.save(realArr, yTs)
	
	#rmse
	rmse=np.sqrt(np.mean(np.square(yTs-pred)))
	
	#mape
	deno=copy.deepcopy(pred); deno[deno<=0]=1
	mape=np.mean(np.abs(np.divide(yTs-pred, deno)))

	#smape
	deno=np.abs(yTs)+np.abs(pred); deno=deno/2; deno=copy.deepcopy(deno); deno[deno<=0]=1
	smape=np.mean(np.divide(np.abs(yTs-pred), deno))
	
	
	dfRes.loc[len(dfRes)]=[hWnd, pWnd, Epochs, rmse, mape, smape]
	dfRes.to_csv(dfResFile, index=False)
	
	print ("rmse mape smape ", rmse, mape, smape)
	K.clear_session()
	
	return 
	
execute()


