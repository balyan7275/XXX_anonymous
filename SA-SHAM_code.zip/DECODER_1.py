import keras
from keras import backend as K
from keras.layers import Layer
import tensorflow as tf
from keras import activations, initializers, constraints

class Decoder(Layer):

	def __init__(self, pwnd=None, kernel_initializer='glorot_uniform', kernel_regularizer=None, kernel_constraint=None, use_bias=True, bias_initializer='zeros', bias_regularizer=None, bias_constraint=None,**kwargs):
		self.pwnd=pwnd
		self.kernel_initializer = keras.initializers.get(kernel_initializer)
		self.kernel_regularizer = keras.regularizers.get(kernel_regularizer)
		self.kernel_constraint = keras.constraints.get(kernel_constraint)
		self.use_bias = use_bias
		self.bias_initializer = keras.initializers.get(bias_initializer)
		self.bias_regularizer = keras.regularizers.get(bias_regularizer)
		self.bias_constraint = keras.constraints.get(bias_constraint)
		self.kernelT, self.kernel, self.b = None, None, None
		super(Decoder, self).__init__(**kwargs)

	def build(self, input_shape):
		#assert isinstance(input_shape, list)
		bt, T, n, d=input_shape
		# Create a trainable weight variable for this layer.
		self.kernel = self.add_weight(name='kernel', shape=(d, d), initializer='uniform', trainable=True, regularizer=self.kernel_regularizer, constraint=self.kernel_constraint)
		#print (" before ", bt, T, n, d, self.kernel.shape, type(T), T, type(self.pwnd), self.pwnd)
		self.kernelT = self.add_weight(name='kernelT', shape=(T, self.pwnd), initializer='uniform', trainable=True, regularizer=self.kernel_regularizer, constraint=self.kernel_constraint)
		#print (" after ", bt, T, n, n, self.kernelT.shape); input("enter")
		#print("kernalT",kernelT.shape)
		if self.use_bias:
			self.b = self.add_weight(shape=(n, n), initializer=self.bias_initializer, regularizer=self.bias_regularizer, constraint=self.bias_constraint, name='{}_b'.format(self.name),)
		super(Decoder, self).build(input_shape)  # Be sure to call this at the end

	def call(self, x):
		#temporal slider
		bt, T, n, d=x.get_shape().as_list()
		x=tf.reshape(x, [-1, n, d, T])
		#print("bt,T,n,d",bt,T,n,d)
		#print("Xshape",x.shape)
		#print("kernalT",self.kernelT.shape)
		x1=tf.matmul(x, self.kernelT)
		#bt, a, n, d=m.get_shape().as_list()
		#m=tf.reshape(m, [-1, n, d, a])
		#x1=tf.matmul(x, self.kernelT)
		bt, n, d, p=x1.get_shape().as_list()
		#print("X1shapebefore",x1.shape)
		
		
		x1=tf.reshape(x1, [-1, p, n, d])
		#print("X1shapeafter",x1.shape)
		x2=tf.matmul(tf.transpose(self.kernelT),x, transpose_b=True)
		bt, n, p, d=x2.get_shape().as_list()
		x2=tf.reshape(x2, [-1 , p ,n ,d])
		x2=tf.matmul(tf.matmul(x2, self.kernel), x1, transpose_b=True)
		#print("X2shapebefore",x2.shape)
		#bt, n, p, d=x2.get_shape().as_list()
		#x2=tf.reshape(x2, [-1 , p ,d ,n])
		#a=tf.transpose(x)
		#print("ashape",a.shape)
		#x2=tf.matmul(self.kernelT,tf.transpose(x))
		#bt, n, d, p=x.get_shape().as_list()
		#print("bt,n,d,p",bt,n,d,p)
		#x=tf.reshape(x, [-1, p, n, d])
		#print("x2shapeafter",x2.shape)
		#print("kernel",self.kernel.shape)
		
		#x=tf.matmul(x1,x2)
		#x1=tf.matmul(tf.matmul(x1, self.kernel), x1, transpose_b=True)
		#x=tf.matmul(x1,x2)
		#print("X2ndlast",x.shape)
		
		if self.use_bias:
			x2+= self.b
		x2=keras.activations.sigmoid(x2)#; print (" shape of output ", x.shape); input("enter")
		print("xlast",x2.shape)
		return x2

	def get_config(self):
		config = super(Decoder, self).get_config()
		config.update({"pwnd": self.pwnd})
		return config

	def compute_output_shape(self, input_shape):
		#assert isinstance(input_shape, list)
		bt, T, n, d=input_shape
		return (bt, self.pwnd, n, n)
		
